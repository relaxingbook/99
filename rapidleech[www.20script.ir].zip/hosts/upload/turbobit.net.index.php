<?php
$upload_services[] = 'turbobit.net';
$max_file_size['turbobit.net'] = 2048;
$page_upload['turbobit.net'] = 'turbobit.net.php';  
?>