<?php
$upload_services[]="wikiupload.com";
$max_file_size["wikiupload.com"]=5000;
$page_upload["wikiupload.com"] = "wikiupload.com.php";
?>