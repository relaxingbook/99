<?php
$upload_services[] = 'sendmyway.com';
$max_file_size['sendmyway.com'] = 1000;
$page_upload['sendmyway.com'] = 'sendmyway.com.php';
?>