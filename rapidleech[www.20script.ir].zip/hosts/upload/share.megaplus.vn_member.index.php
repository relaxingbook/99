<?
$upload_services[]="share.megaplus.vn_member";
$max_file_size["share.megaplus.vn_member"]= 2000;
$page_upload["share.megaplus.vn_member"] = "share.megaplus.vn_member.php";
?>